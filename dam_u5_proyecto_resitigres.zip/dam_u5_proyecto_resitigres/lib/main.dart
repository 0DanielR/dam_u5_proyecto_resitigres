import 'package:dam_u5_proyecto_resitigres/pages/info_resi.dart';
import 'package:dam_u5_proyecto_resitigres/pages/login.dart';
import 'package:dam_u5_proyecto_resitigres/pages/mi_resi.dart';
import 'package:dam_u5_proyecto_resitigres/pages/ofertas.dart';
import 'package:dam_u5_proyecto_resitigres/pages/resi_form.dart';
import 'package:dam_u5_proyecto_resitigres/pages/usuario.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'firebase_options.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Resi-Tigres',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.green,
      ),
      initialRoute: '/',
      routes: {
        '/': (context)=> const login(),
        '/ofertas': (context)=> const ofertas(),
        '/resi': (context)=> const info_resi(),
        '/usuario': (context)=> const usuario(),
        '/miresi': (context)=> const mi_resi(),
        '/form': (context) => resi_form(userEmail: ModalRoute.of(context)!.settings.arguments as String),
      },

    );
  }
}