import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';


FirebaseFirestore db = FirebaseFirestore.instance;
//Leer
Future<List>getResi() async{
  List resi=[];
  //pedir todos los elementos de una coleción
  QuerySnapshot queryAsignacion = await db.collection('oferta_resi').get();
  for (var doc in queryAsignacion.docs){
    final Map<String, dynamic> data = doc.data() as Map<String,dynamic>;
    final ofer = {
      "Lugar": data['Lugar'],
      "Ubicacion": data['Ubicacion'],
      "carrera": data['carrera'],
      "perfil": data['perfil'],
      "uid": doc.id,
    };
    resi.add(ofer);
  }
  return resi;
}
Future<List>getResiUsuario(String usr) async{
  List resi=[];
  //pedir todos los elementos de una coleción
  QuerySnapshot queryAsignacion = await db.collection('residencias_$usr').get();
  for (var doc in queryAsignacion.docs){
    final Map<String, dynamic> data = doc.data() as Map<String,dynamic>;
    final ofer = {
      "Lugar": data['Lugar'],
      "Ubicacion": data['Ubicacion'],
      "carrera": data['carrera'],
      "perfil": data['perfil'],
      "uid": doc.id,
    };
    resi.add(ofer);
  }
  return resi;
}
//Consulta Resi particular
Future<Map<String, dynamic>?> getResipar(String perfil) async {
  QuerySnapshot querySnapshot = await FirebaseFirestore.instance
      .collection('oferta_resi')
      .where('perfil', isEqualTo: perfil)
      .get();

  if (querySnapshot.size == 0) {
    return null;
  }

  final DocumentSnapshot snapshot = querySnapshot.docs[0];
  final Map<String, dynamic> data = snapshot.data() as Map<String, dynamic>;
  final perfiles = {
    "Lugar": data['Lugar'],
    "Ubicacion": data['Ubicacion'],
    "carrera": data['carrera'],
    "perfil": data['perfil'],
    "tel":data['tel'],
    "contacto":data['contacto'],
    "uid": snapshot.id,
  };

  return perfiles;
}
//Guardar
Future<void>addResidencia(String lug,String ubi, String car, String per, String tel, String usr) async{
  await db.collection("oferta_resi").add({
    "Lugar": lug,
    "Ubicacion": ubi,
    "carrera": car,
    "perfil": per,
    "tel": tel,
    "contacto": usr
  });
}
//Actualizar
Future<void>updateAsignacion(String uid, String dcn,String edf, String hor, String mat, String sal) async{
  await db.collection("asignacion").doc(uid).set({
    "docente": dcn,
    "edificio": edf,
    "horario": hor,
    "materia": mat,
    "salon": sal
  });
}
//eliminar
Future<void> deleteResi(String uid,String usr) async{
  String coleccion ="residencias_$usr";
  print("COLECCIÓN: $coleccion");
  await db.collection(coleccion).doc(uid).delete();
}
void createCollection(String lug, String ubi, String car, String usr, String per, String tel) async {
  final String collectionName = 'residencias_$usr';
  try {
    await db.collection(collectionName).add({
      "Lugar": lug,
      "Ubicacion": ubi,
      "carrera": car,
      "perfil": per,
      "tel": tel,
      "contacto": usr
    });
    print('Colección creada exitosamente');
  } catch (e) {
    print('Error al crear la colección: $e');
  }
}
//verificar si existe la colección
Future<bool> existeResi(String usr) async {
  List residencia = [];
  bool sionopues=false;
  String coleccion = 'residencias_$usr';
  // Obtener todos los elementos de una colección
  QuerySnapshot queryAsignacion = await db.collection(coleccion).get();
  if(queryAsignacion!=null){sionopues=true;}
  for (var doc in queryAsignacion.docs) {
    final Map<String, dynamic> data = doc.data() as Map<String, dynamic>;
    final resi = {
      "Lugar": data['Lugar'],
      "Ubicacion": data['Ubicacion'],
      "carrera": data['carrera'],
      "perfil": data['perfil'],
      "tel":data['tel'],
      "contacto":data['contacto'],
      "uid": doc.id,
    };
    residencia.add(resi);
  }
  return sionopues;
}
Future<bool> existeDocumento(String lugar, String ubicacion, String carrera, String usuario, String perfil, String tel) async {
  final QuerySnapshot<Map<String, dynamic>> snapshot = await db
      .collection('residencias_$usuario')
      .where('Lugar', isEqualTo: lugar)
      .where('Ubicacion', isEqualTo: ubicacion)
      .where('carrera', isEqualTo: carrera)
      .where('usuario', isEqualTo: usuario)
      .where('perfil', isEqualTo: perfil)
      .where('tel', isEqualTo: tel)
      .get();

  return snapshot.docs.isNotEmpty;
}


