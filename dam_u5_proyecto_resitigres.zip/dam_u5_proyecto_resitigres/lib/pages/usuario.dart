import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class usuario extends StatefulWidget {
  const usuario({Key? key}) : super(key: key);

  @override
  State<usuario> createState() => _usuarioState();
}

class _usuarioState extends State<usuario> {
  late String usuario;
  late String newPassword;

  @override
  void initState() {
    super.initState();
    usuario = '';
    newPassword = '';
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    fetchUserData();
  }

  void fetchUserData() {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    final String user = arguments['usuario'];

    setState(() {
      usuario = user;
    });
  }

  Future<void> changePassword() async {
    try {
      // Obtén la instancia actual del usuario
      User? user = FirebaseAuth.instance.currentUser;

      if (user != null) {
        // Cambia la contraseña utilizando el método updatePassword
        await user.updatePassword(newPassword);
        print("Contraseña cambiada exitosamente");
        Navigator.pushNamed(context, '/ofertas');
      }
    } catch (e) {
      print("Error al cambiar la contraseña: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Usuario'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Bienvenido:',
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
            ),
            Container(
              alignment: Alignment.center,
              child: Image.asset(
                'assets/usr_icon.png',
                width: 200,
                height: 200,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Usuario: $usuario',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),
            TextField(
              onChanged: (value) {
                newPassword = value;
              },
              decoration: InputDecoration(
                labelText: 'Nueva Contraseña',
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: Colors.green,
                onPrimary: Colors.white,
              ),
              onPressed: changePassword,
              child: Text('Cambiar Contraseña'),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                primary: Colors.red,
                onPrimary: Colors.white,
              ),
              onPressed: () {
                Navigator.pushNamed(context, '/');
              },
              child: const Text("LogOut"),
            ),
          ],
        ),
      ),
    );
  }
}