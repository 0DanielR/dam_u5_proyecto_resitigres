import 'package:flutter/material.dart';
import 'package:dam_u5_proyecto_resitigres/services/firebase_services.dart';

class info_resi extends StatefulWidget {
  const info_resi({Key? key}) : super(key: key);

  @override
  State<info_resi> createState() => _info_resiState();
}

class _info_resiState extends State<info_resi> {
  late TextEditingController verPerfil;
  late String usuarioResi;
  Map<String, dynamic>? resiparData;

  @override
  void initState() {
    super.initState();
    verPerfil = TextEditingController();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    fetchResiparData();
  }

  Future<void> fetchResiparData() async {
    final Map<String, dynamic> arguments = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    final String perfilResi = arguments['perfilResi'];
    final String usuario = arguments['usuario'] as String? ?? '';
    final data = await getResipar(perfilResi);
    setState(() {
      resiparData = data;
      usuarioResi = usuario;
    });
  }


  @override
Widget build(BuildContext context) {
  return Scaffold(
    appBar: AppBar(
      title: const Text('Información de Residencia'),
    ),
    body: Center(
      child: Container(
        padding: const EdgeInsets.all(16),
        child: resiparData != null
            ? Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Image.asset(
                    'assets/itt_escudo.png',
                    width: 200,
                    height: 200,
                  ),
                  Text(
                    'Perfil: ${resiparData!['perfil']}',
                    style: TextStyle(
                      color: Colors.green,
                      fontSize: 32.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 20.0),
                  Text('Lugar: ${resiparData!['Lugar']}'),
                  SizedBox(height: 10.0),
                  Text('Carrera: ${resiparData!['carrera']}'),
                  SizedBox(height: 10.0),
                  Text('Telefono: ${resiparData!['tel']}'),
                  SizedBox(height: 10.0),
                  Text('Ubicación: ${resiparData!['Ubicacion']}'),
                  SizedBox(height: 10.0),
                  Text('Contacto: ${resiparData!['contacto']}'),
                  SizedBox(height: 40.0),
                  Container(
                    width: double.infinity,
                    child: RawMaterialButton(
                      fillColor: Color(0xED000000),
                      elevation: 0.0,
                      padding: EdgeInsets.symmetric(vertical: 20.0),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12.0),
                      ),
                      onPressed: () async {
                        String lugar = '${resiparData!['Lugar']}';
                        String ubicacion = '${resiparData!['Ubicacion']}';
                        String carrera = '${resiparData!['carrera']}';
                        String usuario = usuarioResi;
                        String perfil = '${resiparData!['perfil']}';
                        String tel = '${resiparData!['tel']}';
                        bool residenciaExists = await existeDocumento(lugar, ubicacion, carrera, usuario, perfil, tel);

                        if (!residenciaExists) {
                          print("no existía y se creó");
                          createCollection(lugar, ubicacion, carrera, usuario, perfil, tel);
                          Navigator.pop(context);
                        } else {
                          print("ya existía y no se creó");
                          Navigator.pop(context);
                        }
                      },
                      child: Text(
                        "Guardar en mis residencias",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18.0,
                        ),
                      ),
                    ),
                  )
                ],
              )
            : const Center(
                child: CircularProgressIndicator(),
              ),
      ),
    ),
  );
}
}