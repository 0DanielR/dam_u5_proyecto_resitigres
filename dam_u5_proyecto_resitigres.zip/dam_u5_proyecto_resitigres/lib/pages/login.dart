import 'dart:html';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:dam_u5_proyecto_resitigres/services/auth.dart';
import 'package:firebase_auth/firebase_auth.dart';
class login extends StatefulWidget {
  const login({Key? key}) : super(key: key);

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  String? errorMessage='';

  Future<FirebaseApp> _initializeFiirebase() async{
    FirebaseApp firebaseApp =await Firebase.initializeApp();
    return firebaseApp;
  }
  static Future<User?> loginUsingEmailPassword({
    required String email,
    required String password,
    required BuildContext context
  })async{
    FirebaseAuth auth =FirebaseAuth.instance;
    User? user;
    try{
      UserCredential userCredential = await auth.signInWithEmailAndPassword(
          email: email, password: password);
      user= userCredential.user;
    }on FirebaseAuthException catch (e){
      if(e.code=="user-not-found"){
        print ("No se encontró el usuario");
      }
    }
    return user;
  }
  @override
  Widget build(BuildContext context) {
    TextEditingController _emailCon = TextEditingController();
    TextEditingController _passCon = TextEditingController();
    return Scaffold(backgroundColor: Colors.orangeAccent,
      body: Padding(
        padding: EdgeInsets.all(16.0),

        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children:  [
            const Text("Resi-Tigres",
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 28.0,
                fontWeight: FontWeight.bold
              ),
            ),
            const Text("Login a tu cuenta",
            style: TextStyle(color: Colors.black,fontSize: 44.0,fontWeight: FontWeight.bold),),
            const SizedBox(height: 44.0,),
             TextField(
              controller: _emailCon,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                hintText: "User Email",
                prefixIcon: Icon(Icons.mail, color: Colors.black,)
              ),
            ),
            const SizedBox(height: 26.0,),
             TextField(
              controller: _passCon,
              obscureText: true,
              decoration:const InputDecoration(
                hintText: "User Password",
                prefixIcon: Icon(Icons.lock, color: Colors.black,)
              ),
            ),
            const SizedBox(height: 88.0,),
            Container(
              width: double.infinity,
              child: RawMaterialButton(
              fillColor: const Color(0xED000000),
              elevation: 0.0,
              padding:const EdgeInsets.symmetric(vertical: 20.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0)
              ),
              onPressed: ()async{
                User? user = await loginUsingEmailPassword(email: _emailCon.text, password: _passCon.text, context: context);
                print(user);
                if(user != null){
                  Navigator.pushNamed(context, '/ofertas');
                }else {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text("Usuario no encontrado"),
                      content: Text("Por favor, verifica tu correo electrónico y contraseña."),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: Text("Aceptar"),
                        ),
                      ],
                    ),
                  );
                }
              },child: const Text("Login",style: TextStyle(color: Colors.white,fontSize: 18.0),),),
            )
          ],
        ),
      ),
    );
  }
}
