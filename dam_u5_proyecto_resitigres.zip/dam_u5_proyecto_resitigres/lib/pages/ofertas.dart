import 'package:flutter/material.dart';
import 'package:dam_u5_proyecto_resitigres/services/firebase_services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:dam_u5_proyecto_resitigres/services/auth.dart';

void main() {
  runApp(ofertas());
}

class ofertas extends StatefulWidget {
  const ofertas({Key? key}) : super(key: key);

  @override
  State<ofertas> createState() => _ofertasState();
}

class _ofertasState extends State<ofertas> {
  //autenticación
  final User? user =Auth().currentUser;
  Future<void> signOut() async{
    await Auth().signOut();
  }
  //variable para buscar
  final TextEditingController buscarCon = TextEditingController();
  String searchQuery = '';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'Resi-Tigres',
          style: TextStyle(
            color: Colors.black87,
          ),
        ),
        iconTheme: IconThemeData(color: Colors.black87),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.lightGreen,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    '/usr_icon.png', // Ruta de la imagen
                    width: 64, // Ancho de la imagen
                    height: 64, // Alto de la imagen
                  ),
                  const SizedBox(height: 8),
                   Text(
                    user?.email ?? 'User email',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            ListTile(
              title: Text('Ver ofertas de residencias'),
              onTap: () {
                Navigator.pushNamed(context, "/ofertas");
              },
            ),
            ListTile(
              title: Text(
                'Ofertar residencia',
                style: TextStyle(
                  color: Colors.lightGreen, // Color deseado
                ),
              ),
              onTap: () {
                Navigator.pushNamed(context, "/form", arguments: user?.email ?? 'User email');
              },
            ),

            ListTile(
              title: Text('sign out'),
              onTap: () {
                signOut();
                Navigator.pushNamed(context, "/");
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: buscarCon,
              onChanged: (value) {
                setState(() {
                  searchQuery = value;
                });
              },
              decoration: InputDecoration(
                hintText: 'Buscar',
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Text(
            'Ofertas de Residencia',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          Expanded(
            child:FutureBuilder(
                future: getResi(),
                builder: (context, snapshot) {
                  if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
                if (snapshot.hasError) {
                  return Center(
                     child: Text('Error: ${snapshot.error}'),
                  );
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(
                    child: Text('No hay elementos disponibles.'),
                  );
                }
              return ListView.builder(
                itemCount: snapshot.data?.length, // Cambia esto por la cantidad de elementos que desees mostrar
                itemBuilder: (context, index) {
                  final title = snapshot.data?[index]['perfil']?.toUpperCase() ?? '';
                  final subtitle = snapshot.data?[index]['Lugar']?.toUpperCase() ?? '';
                  final location = snapshot.data?[index]['Ubicacion']?.toUpperCase() ?? '';
                  final career = snapshot.data?[index]['carrera']?.toUpperCase() ?? '';
                  // Filtrar los elementos según el término de búsqueda
                  if (searchQuery.isNotEmpty &&
                      !title.contains(searchQuery.toUpperCase()) &&
                      !subtitle.contains(searchQuery.toUpperCase()) &&
                      !location.contains(searchQuery.toUpperCase()) &&
                      !career.contains(searchQuery.toUpperCase())) {
                    return Container();
                  }
                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.3),
                          spreadRadius: 2,
                          blurRadius: 4,
                          offset: Offset(0, 2),
                        ),
                      ],
                    ),
                    margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Color(0xFFD9D3B4),
                        backgroundImage: AssetImage('/usr_icon.png'),
                      ),
                      title: Text('${snapshot.data?[index]['perfil']}'),
                      subtitle: Text('${snapshot.data?[index]['Ubicacion']}'),
                      trailing: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '${snapshot.data?[index]['carrera']}',
                            style: TextStyle(
                              color: Color(0xFFAAB7A0),
                              fontSize: 14,
                            ),
                          ),
                          SizedBox(height: 4),
                          RichText(
                            text: TextSpan(
                              text: '',
                              style: TextStyle(
                                color: Colors.black,
                              ),
                              children: <TextSpan>[
                                TextSpan(
                                  text: '${snapshot.data?[index]['Lugar']}',
                                  style: TextStyle(
                                    color:Color(0xFF455735) ,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      onTap: () async{
                        await Navigator.pushNamed(context, "/resi",arguments:{
                          "perfilResi":snapshot.data?[index]['perfil'],
                          "usuario": user?.email ?? 'User email'
                        });
                      },
                    ),
                  );
                },
              );
                },
            ),
          ),
          ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.lightGreen,
        selectedItemColor: Colors.lightGreenAccent, // Color de los íconos seleccionados
        unselectedItemColor: Colors.white70, // Color de los íconos no seleccionados
        onTap: (int index) {
          switch (index) {
            case 0:
              Navigator.pushNamed(context, '/ofertas');
              break;
            case 1:
              Navigator.pushNamed(context, '/usuario',arguments:{
                "usuario": user?.email ?? 'User email'
              });
              break;
            case 2:
              Navigator.pushNamed(context, "/miresi",arguments: {"usuario": user?.email ?? 'User email'});
              break;
          }
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Inicio',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Usuario',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_balance),
            label: 'Mi residencia',
          ),

        ],
      ),
    );
  }
}
