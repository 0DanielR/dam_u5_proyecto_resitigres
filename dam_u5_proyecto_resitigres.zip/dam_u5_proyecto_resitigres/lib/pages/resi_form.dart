import 'package:flutter/material.dart';

import '../services/firebase_services.dart';

class resi_form extends StatelessWidget {
  final String userEmail;

  const resi_form({required this.userEmail});

  @override
  Widget build(BuildContext context) {
    TextEditingController lugarController = TextEditingController();
    TextEditingController ubicacionController = TextEditingController();
    TextEditingController carreraController = TextEditingController();
    TextEditingController perfilController = TextEditingController();
    TextEditingController telefonoController = TextEditingController();

    return Scaffold(
      appBar: AppBar(
        title: Text('Ofertar residencia'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Ofertar de Residencia',
              style: TextStyle(
                fontSize: 24.0,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 16.0),
            TextFormField(
              controller: lugarController,
              decoration: InputDecoration(
                labelText: 'Lugar',
              ),
            ),
            TextFormField(
              controller: ubicacionController,
              decoration: InputDecoration(
                labelText: 'Ubicación',
              ),
            ),
            TextFormField(
              controller: carreraController,
              decoration: InputDecoration(
                labelText: 'Carrera',
              ),
            ),
            TextFormField(
              controller: perfilController,
              decoration: InputDecoration(
                labelText: 'Perfil',
              ),
            ),
            TextFormField(
              controller: telefonoController,
              decoration: InputDecoration(
                labelText: 'Teléfono',
              ),
            ),
            SizedBox(height: 16.0),
            TextFormField(
              initialValue: userEmail,
              enabled: false,
              decoration: InputDecoration(
                labelText: 'Correo Electrónico',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                String lugar = lugarController.text;
                String ubicacion = ubicacionController.text;
                String carrera = carreraController.text;
                String perfil = perfilController.text;
                String telefono = telefonoController.text;
                String usuario = userEmail;

                if (lugar.isEmpty ||
                    ubicacion.isEmpty ||
                    carrera.isEmpty ||
                    perfil.isEmpty ||
                    telefono.isEmpty) {
                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text('Campos incompletos'),
                        content: Text('Por favor, completa todos los campos.'),
                        actions: [
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: Text('Aceptar'),
                          ),
                        ],
                      );
                    },
                  );
                } else {
                  addResidencia(lugar, ubicacion, carrera, perfil, telefono, usuario);
                  Navigator.pushNamed(context, "/ofertas", arguments:usuario);
                }
              },
              child: Text('Enviar'),
            ),

          ],
        ),
      ),
    );
  }
}
