import 'package:flutter/material.dart';
import 'package:dam_u5_proyecto_resitigres/services/firebase_services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:dam_u5_proyecto_resitigres/services/auth.dart';

class mi_resi extends StatefulWidget {
  const mi_resi({Key? key}) : super(key: key);

  @override
  State<mi_resi> createState() => _mi_resiState();
}

class _mi_resiState extends State<mi_resi> {
  late User? user;
  late String usuario;
  late String newPassword;

  @override
  void initState() {
    super.initState();
    usuario = '';
    newPassword = '';
    user = Auth().currentUser;
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    fetchUserData();
  }

  void fetchUserData() {
    final Map arguments = ModalRoute.of(context)!.settings.arguments as Map;
    final String user = arguments['usuario'];

    setState(() {
      usuario = user ?? '';
    });
  }

  Future<void> signOut() async {
    await Auth().signOut();
  }

  @override
  Widget build(BuildContext context) {
    print(usuario);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          'Resi-Tigres',
          style: TextStyle(
            color: Colors.black87,
          ),
        ),
        iconTheme: IconThemeData(color: Colors.black87),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.lightGreen,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(
                    '/usr_icon.png', // Ruta de la imagen
                    width: 64, // Ancho de la imagen
                    height: 64, // Alto de la imagen
                  ),
                  const SizedBox(height: 8),
                  Text(
                    user?.email ?? 'User email',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
            ListTile(
              title: Text('Ver ofertas de residencias'),
              onTap: () {
                Navigator.pushNamed(context, "/ofertas");
              },
            ),
            ListTile(
              title: Text(
                'Ofertar residencia',
                style: TextStyle(
                  color: Colors.lightGreen, // Color deseado
                ),
              ),
              onTap: () {
                Navigator.pushNamed(context, "/form",
                    arguments: {"usuario": user?.email ?? 'User email'});
              },
            ),
            ListTile(
              title: Text('Sign Out'),
              onTap: () {
                signOut();
                Navigator.pushNamed(context, "/");
              },
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
          ),
          Text(
            'Mis residencias',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          Expanded(
            child: FutureBuilder(
              future: getResiUsuario(usuario),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
                if (snapshot.hasError) {
                  return Center(
                    child: Text('Error: ${snapshot.error}'),
                  );
                }
                if (!snapshot.hasData || snapshot.data!.isEmpty) {
                  return Center(
                    child: Text('No hay elementos disponibles.'),
                  );
                }
                return ListView.builder(
                  itemCount: snapshot.data?.length,
                  itemBuilder: (context, index) {
                    final resiItem = snapshot.data?[index];

                    return Dismissible(
                      key: Key(resiItem['id'] ?? ''),
                      direction: DismissDirection.endToStart,
                      confirmDismiss: (direction) async {
                        return await showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text('Eliminar residencia'),
                              content: Text('¿Estás seguro de que deseas eliminar esta residencia?'),
                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop(false);
                                  },
                                  child: Text('Cancelar'),
                                ),
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop(true);
                                    print("USUARIO: $usuario");
                                    print("DOCUMENTO: $resiItem['id']");
                                  },
                                  child: Text('Eliminar'),
                                ),
                              ],
                            );
                          },
                        );
                      },
                      onDismissed: (direction) {
                        if (direction == DismissDirection.endToStart) {
                          setState(() {
                            // Eliminar el elemento del ListView
                            snapshot.data?.removeAt(index);
                          });

                          final String? residenciaId = resiItem['uid'];
                          print("ID: $residenciaId");
                          if (residenciaId != null) {
                            // Eliminar el elemento de la base de datos
                            deleteResi(residenciaId, usuario);
                          }

                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text('Residencia eliminada'),
                            ),
                          );
                        }
                      },
                      background: Container(
                        color: Colors.red,
                        alignment: Alignment.centerRight,
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        child: Icon(
                          Icons.delete,
                          color: Colors.white,
                        ),
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.3),
                              spreadRadius: 2,
                              blurRadius: 4,
                              offset: Offset(0, 2),
                            ),
                          ],
                        ),
                        margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: Color(0xFFD9D3B4),
                            backgroundImage: AssetImage('/usr_icon.png'),
                          ),
                          title: Text('${resiItem['perfil']}'),
                          subtitle: Text('${resiItem['Ubicacion']}'),
                          trailing: Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                '${resiItem['carrera']}',
                                style: TextStyle(
                                  color: Color(0xFFAAB7A0),
                                  fontSize: 14,
                                ),
                              ),
                              SizedBox(height: 4),
                              RichText(
                                text: TextSpan(
                                  text: '',
                                  style: TextStyle(
                                    color: Colors.black,
                                  ),
                                  children: <TextSpan>[
                                    TextSpan(
                                      text: '${resiItem['Lugar']}',
                                      style: TextStyle(
                                        color: Color(0xFF455735),
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          onTap: () async {
                            await Navigator.pushNamed(context, "/resi", arguments: {
                              "perfilResi": resiItem['perfil'],
                              "usuario": user?.email ?? 'User email',
                            });
                          },
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        backgroundColor: Colors.lightGreen,
        selectedItemColor: Colors.lightGreenAccent, // Color de los íconos seleccionados
        unselectedItemColor: Colors.white70, // Color de los íconos no seleccionados
        onTap: (int index) {
          switch (index) {
            case 0:
              Navigator.pushNamed(context, '/ofertas');
              break;
            case 1:
              Navigator.pushNamed(context, '/usuario', arguments: {
                "usuario": user?.email ?? 'User email',
              });
              break;
            case 2:
              Navigator.pushNamed(context, "/miresi", arguments: {"usuario": user?.email ?? 'User email'});
              break;
          }
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Inicio',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Usuario',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_balance),
            label: 'Mi residencia',
          ),
        ],
      ),
    );
  }
}
